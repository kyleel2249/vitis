'use client';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type CartItem = {
  id: string;
  productId: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  quantity: number;
  variant?: string;
  vendorId?: string;
  vendorName?: string;
};

type CartStore = {
  items: CartItem[];
  addItem: (item: Omit<CartItem, 'quantity'> & { quantity?: number }) => void;
  removeItem: (productId: string, variant?: string) => void;
  updateQuantity: (productId: string, quantity: number, variant?: string) => void;
  clearCart: () => void;
  totalItems: () => number;
  totalPrice: () => number;
  isInCart: (productId: string, variant?: string) => boolean;
};

export const useCart = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],

      addItem: (item) =>
        set((state) => {
          const key = item.productId + (item.variant || '');
          const existing = state.items.find(
            (i) => i.productId + (i.variant || '') === key
          );
          if (existing) {
            return {
              items: state.items.map((i) =>
                i.productId + (i.variant || '') === key
                  ? { ...i, quantity: i.quantity + (item.quantity || 1) }
                  : i
              ),
            };
          }
          return {
            items: [...state.items, { ...item, quantity: item.quantity || 1 }],
          };
        }),

      removeItem: (productId, variant) =>
        set((state) => ({
          items: state.items.filter(
            (i) => !(i.productId === productId && (i.variant || '') === (variant || ''))
          ),
        })),

      updateQuantity: (productId, quantity, variant) =>
        set((state) => ({
          items:
            quantity <= 0
              ? state.items.filter(
                  (i) => !(i.productId === productId && (i.variant || '') === (variant || ''))
                )
              : state.items.map((i) =>
                  i.productId === productId && (i.variant || '') === (variant || '')
                    ? { ...i, quantity }
                    : i
                ),
        })),

      clearCart: () => set({ items: [] }),

      totalItems: () => get().items.reduce((sum, i) => sum + i.quantity, 0),

      totalPrice: () =>
        get().items.reduce((sum, i) => sum + i.price * i.quantity, 0),

      isInCart: (productId, variant) =>
        get().items.some(
          (i) => i.productId === productId && (i.variant || '') === (variant || '')
        ),
    }),
    { name: 'commerce-os-cart' }
  )
);
